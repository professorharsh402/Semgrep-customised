package jaxrs.security;

public class Pair {
    public String getP1() {
        return "";
    }

    public String getP2() {
        return "";
    }
}
