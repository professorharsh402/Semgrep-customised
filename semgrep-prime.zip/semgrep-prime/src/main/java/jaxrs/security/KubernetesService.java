package jaxrs.security;

public class KubernetesService {
    public String getMessage() {
        return "";
    }
}
