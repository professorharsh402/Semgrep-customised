package lang.correctness;

class BarEx2 {
    void main() {
        boolean myBoolean;

        //myBoolean == myBoolean;

        // ruleid:assignment-comparison
        if (myBoolean = true) {
          //  continue;
            /*
            Continue cannot be used without loop
             */
        }

        // ok:assignment-comparison
        if (myBoolean) {

        }
    }
}
