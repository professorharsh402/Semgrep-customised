package lang.correctness;

class BarEx {
/*    void main() {
        boolean myBoolean;

        //myBoolean == myBoolean;

        // ruleid:eqeq
        if (myBoolean == myBoolean) {
            continue;
        }

        // ruleid:eqeq
        if (myBoolean != myBoolean) {
            continue;
        }

        float someFloat = 0;
        // ruleid:eqeq
        if (someFloat != someFloat) {
            continue;
        }
    } */
}
