package lang.security.audit;

import java.security.NoSuchAlgorithmException;
import java.util.regex.Pattern;
import javax.crypto.KeyGenerator;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

// cf. https://find-sec-bugs.github.io/bugs.htm#BLOWFISH_KEY_SIZE
class Cls1 {

    public void unsafeKeySize() {
        // ruleid: blowfish-insufficient-key-size
        KeyGenerator keyGen = null;
        try {
            keyGen = KeyGenerator.getInstance("Blowfish");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
        keyGen.init(64);
    }

    public void safeKeySize() {
        // ok: blowfish-insufficient-key-size
        KeyGenerator keyGen = null;
        try {
            keyGen = KeyGenerator.getInstance("Blowfish");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
        keyGen.init(128);
    }

    public void superSafeKeySize() {
        // ok: blowfish-insufficient-key-size
        KeyGenerator keyGen = null;
        try {
            keyGen = KeyGenerator.getInstance("Blowfish");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
        keyGen.init(448);
    }
}
