package lang.security.audit.xxe;

import com.squareup.okhttp.Call;

public class ApiClient {
    public void execute(Call call) {
    }

    public void execute(String call) {
    }

    public void run(Call call) {
    }
}
