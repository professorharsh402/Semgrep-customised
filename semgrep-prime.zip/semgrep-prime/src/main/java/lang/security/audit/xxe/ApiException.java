package lang.security.audit.xxe;

public class ApiException extends Throwable {
}
