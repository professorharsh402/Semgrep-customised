package lang.security.audit.crypto.ssl;

import java.net.Socket;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import javax.net.ssl.*;

//cf. https://find-sec-bugs.github.io/bugs.htm#WEAK_TRUST_MANAGER
class TrustAllManager implements X509TrustManager {

    // ruleid:insecure-trust-manager
    @Override
    public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
        //Trust any client connecting (no certificate validation)
    }

    // ruleid:insecure-trust-manager
    @Override
    public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
        //Trust any remote server (no certificate validation)
    }

    // ruleid:insecure-trust-manager
    @Override
    public X509Certificate[] getAcceptedIssuers() {
        return null;
    }
}

public class GoodTrustManager implements X509TrustManager {

    protected KeyStore loadKeyStore() {
        KeyStore ks = null;
        try {
            ks = KeyStore.getInstance(KeyStore.getDefaultType());
        } catch (KeyStoreException e) {
            throw new RuntimeException(e);
        }
        return ks;
    }

    // ok:insecure-trust-manager
    @Override
    public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
        KeyStore ks = loadKeyStore();
        try {
            TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");

            tmf.init(ks);
            tmf.getTrustManagers()[0].checkClientTrusted(x509Certificates, s);
        } catch (KeyStoreException e) {
            throw new RuntimeException(e);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }

    }

    // ok:insecure-trust-manager
    @Override
    public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
        KeyStore ks = loadKeyStore();

        try {
            TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
            tmf.init(ks);
            tmf.getTrustManagers()[0].checkClientTrusted(x509Certificates, s);
        } catch (KeyStoreException e) {
            throw new RuntimeException(e);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }

    }

    // ok:insecure-trust-manager
    @Override
    public X509Certificate[] getAcceptedIssuers() {
        return loadKeyStore().getCertificate("alias");
    }
}
 final class TMClass {

    private static final X509TrustManager TM = new X509TrustManager() {
        // ruleid:insecure-trust-manager
        @Override
        public void checkClientTrusted(final X509Certificate[] chain, final String authType)
                throws CertificateException {
        }

        // ruleid:insecure-trust-manager
        @Override
        public void checkServerTrusted(final X509Certificate[] chain, final String authType)
                throws CertificateException {
        }

        // ruleid:insecure-trust-manager
        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return null;
        }
    };
}

final class TMEClass {
        TrustManager[] trustAllCerts = new TrustManager[]{new X509ExtendedTrustManager() {
        // ruleid:insecure-trust-manager
        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return null;
        }

        // ruleid:insecure-trust-manager
        @Override
        public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        }

        // ruleid:insecure-trust-manager
        @Override
        public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        }

        // ruleid:insecure-trust-manager
        @Override
        public void checkClientTrusted(X509Certificate[] chain, String authType, Socket socket) throws CertificateException {
        }

        // ruleid:insecure-trust-manager
        @Override
        public void checkClientTrusted(X509Certificate[] chain, String authType, SSLEngine engine) throws CertificateException {
        }

        // ruleid:insecure-trust-manager
        @Override
        public void checkServerTrusted(X509Certificate[] chain, String authType, Socket socket) throws CertificateException {
        }

        // ruleid:insecure-trust-manager
        @Override
        public void checkServerTrusted(X509Certificate[] chain, String authType, SSLEngine engine) throws CertificateException {
        }
    }};
}
