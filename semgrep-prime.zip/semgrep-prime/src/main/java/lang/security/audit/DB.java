package lang.security.audit;

import java.sql.Connection;

public class DB {
    public static Connection getConnection() {
    }
}
