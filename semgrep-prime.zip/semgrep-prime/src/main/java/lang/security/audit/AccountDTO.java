package lang.security.audit;

public class AccountDTO {
}
