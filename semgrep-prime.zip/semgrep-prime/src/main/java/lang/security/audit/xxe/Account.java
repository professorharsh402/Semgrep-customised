package lang.security.audit.xxe;

public class Account {
}
