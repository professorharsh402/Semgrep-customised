package log4j.security;


import org.apache.log4j.Logger;

import javax.xml.ws.spi.http.HttpExchange;
import javax.xml.ws.spi.http.HttpHandler;
import java.io.*;
import java.util.*;

//log4j-message-lookup-injection
public class VulnerableLog4jExampleHandler extends HttpHandler {

  static Logger log = Logger.getLogger(VulnerableLog4jExampleHandler.class.getName());

  public void handle(HttpExchange he) throws IOException {
    String userAgent = he.getRequestHeader("user-agent");
    // ruleid: log4j-message-lookup-injection
    log.info("Request User Agent:" + userAgent);

  }
}
