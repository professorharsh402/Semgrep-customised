package rmi.security;

import java.rmi.Remote;

public class BSidesServiceServerImpl implements Remote {
}
