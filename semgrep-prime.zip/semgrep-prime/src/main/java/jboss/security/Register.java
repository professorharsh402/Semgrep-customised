package jboss.security;

public class Register {
}
