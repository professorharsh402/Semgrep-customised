package jboss.security;

public class User {
    public String getUsername() {
        return "";
    }
}
