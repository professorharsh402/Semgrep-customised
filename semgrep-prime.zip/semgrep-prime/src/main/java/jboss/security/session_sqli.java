package jboss.security;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionBuilder;
import org.hibernate.SessionFactory;

class Cls extends HttpServlet
{
    private static org.apache.log4j.Logger log = Logger.getLogger(Register.class);
    private SessionFactory sessionFactory;

    // ruleid:find-sql-string-concatenation
    protected void danger(String ean) {
        Session session = this.sessionFactory.openSession();

        String query = "select foo from bar where" + ean + " limit 1";
        try {
            PreparedStatement ps = (PreparedStatement) session.createQuery(query);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Integer item = rs.getInt("foo");
            }
        } catch (SQLException e) {
            log.error("Error!", e);
        } finally {
            session.close();
        }
    }
    // ruleid:find-sql-string-concatenation
    protected void danger2(String biz) {
        String query = "select foo from bar where" + biz + " limit 1";
        Session session = this.sessionFactory.openSession();
        Connection  con;
        try {
            con = DriverManager.getConnection(String.valueOf(Class.forName("org.apache.derby.jdbc.ClientDriver")));
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Integer item = rs.getInt("foo");
            }
        } catch (SQLException e) {
            log.error("Error!", e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } finally {
            session.close();
        }
    }

    // ok:find-sql-string-concatenation
    protected int ok(String foo) throws ServletException, IOException {
        String query = "select foo from bar where ? limit 1";
        Session session = this.sessionFactory.openSession();
        Connection  con;
        try {
            con = DriverManager.getConnection(String.valueOf(Class.forName("org.apache.derby.jdbc.ClientDriver")));
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1,foo);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt("foo");
            }
        } catch (SQLException e) {
            log.error("Error!", e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } finally {
            session.close();
        }
        return 0;
    }
}
