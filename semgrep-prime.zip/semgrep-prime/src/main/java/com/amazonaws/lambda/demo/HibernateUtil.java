package com.amazonaws.lambda.demo;

import org.hibernate.SessionFactory;

public class HibernateUtil {
    public static SessionFactory getSessionFactory() {
        return null;
    }
}
