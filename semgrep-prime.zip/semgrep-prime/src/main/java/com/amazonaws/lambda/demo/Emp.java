package com.amazonaws.lambda.demo;

public class Emp {
}
