package com.amazonaws.lambda.demo;

public class Request {
    public Object emp_id;
    public Object month;
    public Object year;
    public Object overtime;

    public int getMonth() {
        return 0;
    }

    public int getYear() {
        return 0;
    }

    public int getOvertime() {
        return 0;
    }

    public int getEmp_id() {
        return 0;
    }
}
