package jjwt.security;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import java.security.Key;

//jwt-none-alg
public class JWTNoneAlg
{
    private static void bad1() {
        // ruleid: jjwt-none-alg
        String jws = Jwts.builder()
                .setSubject("Bob")
                .compact();
    }

    private static void ok1() {
        Key key = Keys.secretKeyFor(SignatureAlgorithm.HS256);
        // ok: jjwt-none-alg
        String jws = Jwts.builder()
                .setSubject("Bob")
                .signWith(key)
                .compact();
    }

    public static void main( String[] args )
    {
        bad1();
        ok1();
    }
}
